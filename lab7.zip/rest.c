#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

int main(void) {
  float rest = 0;
  rest = GetFloat();
  printf("%f\n",rest );
  return 0;
}
