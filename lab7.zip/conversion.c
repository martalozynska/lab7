#include <stdio.h>
int main(void)
{
 // some sample variables
  char c;
  double d, j;
  float f;
  int i;
 // report the sizes of variables' types
  printf("char: %d\n", sizeof(c));
  printf("double: %d\n", sizeof(d));
  printf("float: %d\n", sizeof(f));
  printf("int: %d\n", sizeof(i));
}
